package com.marchengraffiti.nearism.nearism.firebase;

public interface MyCallback {
    void onCallback(String value);
}
